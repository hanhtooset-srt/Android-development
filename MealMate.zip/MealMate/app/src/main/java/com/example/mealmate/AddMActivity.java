package com.example.mealmate;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.text.DateFormat;
import java.util.Calendar;
public class AddMActivity extends AppCompatActivity {

    private EditText uploadTitle, uploadIng, uploadDesc;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_mactivity);

        // Initialize UI components
        uploadTitle = findViewById(R.id.uploadTitle);
        uploadIng = findViewById(R.id.uploadIng);
        uploadDesc = findViewById(R.id.uploadDesc);
        saveButton = findViewById(R.id.saveButton);

        // Handle save button click
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadData();
            }
        });
    }

    // Upload data to Firebase
    public void uploadData() {

        String title = uploadTitle.getText().toString();
        String ing = uploadIng.getText().toString();
        String desc = uploadDesc.getText().toString();

        // Check if all fields are filled
        if (title.isEmpty() || ing.isEmpty() || desc.isEmpty()) {
            Toast.makeText(AddMActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a DataClass object to save to Firebase
        DataClass dataClass = new DataClass(title, ing, desc);

        // Get the current date to use as the key in the database
        String currentDate = DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());

        // Save the data to Firebase
        FirebaseDatabase.getInstance().getReference("Meals").child(
                currentDate)
                .setValue(dataClass)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(AddMActivity.this, "Saved", Toast.LENGTH_SHORT).show();
                            finish();  // Close the activity after saving
                        } else {
                            // Log the error message for debugging
                            Log.e("FirebaseError", "Error saving data", task.getException());
                            Toast.makeText(AddMActivity.this, "Failed to save data", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Log failure
                        Log.e("FirebaseError", "Failure: " + e.getMessage());
                        Toast.makeText(AddMActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}


