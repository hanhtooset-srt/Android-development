package com.example.mealmate;


import android.app.AlertDialog;
import android.content.Context;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mealmate.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import com.github.clans.fab.FloatingActionButton;
public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemsHolder> {

    private Context context;
    private ArrayList<Map<String,Object>> savedItem =new ArrayList<>();

    public ItemAdapter(Context context, ArrayList<Map<String,Object>>savedItem){
        this.context=context;
        this.savedItem=savedItem;

    }

    @NonNull
    @Override
    public ItemAdapter.ItemsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(context).inflate(R.layout.recycler_list,parent,false);
        return new ItemsHolder(v);
    }



    @Override
    public void onBindViewHolder(@NonNull ItemAdapter.ItemsHolder holder, int position) {
        Map<String,Object>recipe =savedItem.get(position);
        holder.name.setText(recipe.get("name").toString());

        if(!recipe.isEmpty()){
            if((boolean) recipe.get("purchased")){
                holder.editButton.setImageResource(R.drawable.baseline_check_24);
            }else{
                holder.editButton.setImageResource(R.drawable.baseline_edit_24);
            }
        }


    }

    @Override
    public int getItemCount() {
        return savedItem.size();
    }

    public static class ItemsHolder extends RecyclerView.ViewHolder{

        TextView name;
        ImageView editButton;
        public ItemsHolder(@NonNull View v){
            super(v);
            name = v.findViewById(R.id.listname);
            editButton = v.findViewById(R.id.editButton);

        }
    }

    private void showEditDialog(String name) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.add_items, null);
        builder.setView(dialogView);

        EditText itemName = dialogView.findViewById(R.id.editlistname);
        itemName.setText(name);

        Button saveButton = dialogView.findViewById(R.id.addlistbuttom);

        AlertDialog dialog = builder.create();

        saveButton.setOnClickListener(v1 -> {
            String newItemName = itemName.getText().toString();

            if (newItemName.isEmpty()) {
                Toast.makeText(context, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                updateItem(name, newItemName);
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void updateItem(String name, String newItemName){

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        String uid = mAuth.getUid();

        // Collection reference
        // Define the collection reference
        CollectionReference ingredientListRef = db.collection("ShoppingLists").document(uid).collection("items");
        // Query for documents where "name" matches the parameter and delete them
        // Fetch the documents in the collection
        ingredientListRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                for (QueryDocumentSnapshot document : task.getResult()) {
                    // Get the ingredients array
                    String docId = document.getId();
                    String itemName = document.get("name").toString();
                    Boolean purchased = (Boolean)document.get("purchased");
                    Map<String, Object> item = new HashMap<>();
                    item.put("name", newItemName);
                    item.put("purchased", purchased);
                    Log.d("Item update", "markAsPurchhased: "+itemName);

                    if(itemName.equals(name)){
                        ingredientListRef.document(docId)
                                .update(item)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        Log.d("Item update", "onSuccess: Item updated");
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.d("Item update", "onFailure: Item cannot be updated");
                                    }
                                });
                    }

                }
            } else {
                Log.w("Firestore", "Error getting documents: ", task.getException());
            }
        });
    }
}
